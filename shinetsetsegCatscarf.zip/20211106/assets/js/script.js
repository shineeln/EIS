ScrollReveal({ reset: true });
ScrollReveal().reveal('.figure', {
    delay:300,
    distance:'200px',
    origin:'bottom'
});